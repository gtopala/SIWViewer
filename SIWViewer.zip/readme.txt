SIWViewer requires Microsoft .NET Framework 4.6
SIWViewer2 requires Microsoft .NET Framework 2.0